exports.TOKEN = 'ODMzMTg3MTcxODYyOTcwMzY4.YHusBQ.mN28pOAMcSQV7FQZOFrc9IOcPg8';

exports.PREFIX = '.';

exports.GOOGLE_API_KEY = '';

exports.GENIUS_API_KEY = '';

exports.news_API = '';

exports.giphy_API = '';

exports.AME_API = 'bb03f373caa534fcfcbaeae177a65134f44a6e57ba7a7b098be273867b376d8a677ddae3c23c6ded4fec8288573945e8c3483689deb13f229376ad4b5b60231d';
